import java.util.ArrayList;


public class Customer extends User {
    private ArrayList<Product> shoppingCart;
    public Customer(String username, String password, ArrayList<Product> shoppingCart) {
        super(username, password);
        this.shoppingCart = shoppingCart;
    }
    public Customer(String username, String password) {
        super(username, password);
        shoppingCart = new ArrayList<>();
    }

    public void writeFile() {

    }


}